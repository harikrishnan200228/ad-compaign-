import streamlit as st
import pandas as pd
import joblib

# Load the trained model
model = joblib.load('random_forest_model.pkl')

# Features used during training
features = [
    'campaign_fee', 'campaign_level', 'campaign_type', 'discount_rate',
    'email_rate', 'limit_info', 'resource_amount', 'hour_resources',
    'price', 'product_level'
]

# Streamlit UI
st.title("📊 Campaign Order Predictor")

# Input form
campaign_fee = st.number_input("Campaign Fee", value=1000)
campaign_level = st.number_input("Campaign Level", value=1)
campaign_type = st.number_input("Campaign Type", value=1)
discount_rate = st.number_input("Discount Rate", value=0.1)
email_rate = st.number_input("Email Rate", value=0.2)
limit_info = st.number_input("Limit Info", value=0)
resource_amount = st.number_input("Resource Amount", value=10)
hour_resources = st.number_input("Hour Resources", value=100)
price = st.number_input("Price", value=140.0)
product_level = st.number_input("Product Level", value=1)

if st.button("Predict Orders"):
    # Prepare input data with the exact same feature names and order
    input_data = pd.DataFrame([[
        campaign_fee, campaign_level, campaign_type, discount_rate,
        email_rate, limit_info, resource_amount, hour_resources,
        price, product_level
    ]], columns=features)

    prediction = model.predict(input_data)[0]
    st.success(f"📦 Predicted Orders: {int(prediction)}")
